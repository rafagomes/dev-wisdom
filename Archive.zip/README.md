# dev-wisdom
A collection of developers wisdom funny phrases