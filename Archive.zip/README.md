# tretas-wisdom
A collection of tretas wisdom funny phrases